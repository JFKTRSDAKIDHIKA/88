polo(){
    cd $macroo
}
